/*
CH-230-A
a9 p1.c
Abhilekh Pandey
ab.pandey@jacobs-universi
*/

#include <iostream>

int main(void)//int argc, char **argv)
{   
    std::string s;
    std::cin >> s;
    std::cout << "Your country is: " << s << std::endl;
    return 0;
}