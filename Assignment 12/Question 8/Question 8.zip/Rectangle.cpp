#include <iostream>
#include "Rectangle.h"

Rectangle::Rectangle(const char *n, double a, double b) : Area(n)
{
    std::cout << "Creating a Rectangle..." << std::endl;
    length = a;
    width = b;
}

Rectangle::~Rectangle()
{
}

double Rectangle::calcArea() const
{
    std::cout << "calcArea of Rectangle...";
    return length * width;
}

double Rectangle::calcPeri() const
{
    std::cout << "calcPeri of Rectangle...";
    return 2 * (length + width);
}