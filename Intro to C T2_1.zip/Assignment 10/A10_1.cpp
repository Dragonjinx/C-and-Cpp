/*
CH-230-A
a9 p11.c
Abhilekh Pandey
ab.pandey@jacobs-universi
*/

#include <iostream>

int main()
{
    
}