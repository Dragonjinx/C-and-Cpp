/*
CH-230-A
a2 p2.c
Abhilekh Pandey
abpandey@jacobs-university.de
*/

#include <stdio.h>

int main() {
    
    char C;
    
    /*printf("Enter a character: "); */
    
    scanf("%c", &C);
    
    printf("character=%c\n", C);
    
    printf("decimal=%d\n", C);
    
    printf("octal=%o\n", C);
    
    printf("hexadecimal=%x\n", C);
    
    return 0;
}