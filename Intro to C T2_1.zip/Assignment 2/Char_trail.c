#include <stdio.h>

int main(){
    char a;
    scanf("%c", &a);
    getchar();
    printf("Your character is: %c \n", a);
    return 0;
}