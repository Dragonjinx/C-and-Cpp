/*
CH-230-A
a1 p6.c
Abhilekh Pandey
abpandey@jacobs-university.de
*/

#include <stdio.h>

int main() {
    char c = 'F';
    printf("c + 3 = %c\n", c + 3);
    printf("ASCII Code = %d\n", c + 3);
    return 0;
}